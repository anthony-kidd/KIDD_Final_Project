# Program Name: The Electrician's Calculator
# Author: Anthony Kidd
# Version: 1.0
# Date of Last Revision: 12/17/2023
# Description: This program allows anyone to complete the 
# necessary calculations used when by electricians daily. 
# I chose to write this because I am an electrician and I believe this would be a good tool to have.
# --------------------------------------

# Importing modules
from tkinter import *
from tkinter import ttk
from PIL import ImageTk,Image

root = Tk()
root.title("Electrician's Calculator")
orange="#EF7338"
blue="#38b4ef"
root.iconbitmap("icon.ico")
root.configure(bg=orange)
root.geometry("500x400")

notebook = ttk.Notebook(root)

welcome_tab = Frame(notebook, bg=orange)
watts_tab = Frame(notebook, bg=orange)
amps_tab = Frame(notebook, bg=orange)
volts_tab = Frame(notebook, bg=orange)

notebook.add(welcome_tab,text="Welcome!")
notebook.add(watts_tab,text="Watts")
notebook.add(amps_tab,text="Amps")
notebook.add(volts_tab,text="Volts")
notebook.pack(expand=True, fill="both")



# Defining Images

ohms_law = ImageTk.PhotoImage(Image.open("ohms_law_chart.png"))
apollo = ImageTk.PhotoImage(Image.open("apollo.jpg"))



# Defining Functions


# Watts Function
def watts():
    watts_tab_watts_e.delete(0, END)

    try:
        volts_str = watts_tab_volts_e.get()
        volts = int(volts_str)
        watts_tab_error_Label.configure(text='', bg=orange, fg=orange)
    except ValueError:
        watts_tab_error_Label.configure(text="ERROR: Invalid input. Positive numbers only, please.", bg='white', fg='red')
        return

    try:
        amps_str = watts_tab_amps_e.get()
        amps = int(amps_str)
        watts_tab_error_Label.configure(text='', bg=orange, fg=orange)
    except ValueError:
        watts_tab_error_Label.configure(text="ERROR: Invalid input. Positive numbers only, please.", bg='white', fg='red')
        return
    
    if amps > 0 and volts > 0:
        watts_tab_watts_e.delete(0, END)
        watts_tab_watts_e.insert(0,amps*volts)
    else:
        watts_tab_error_Label.configure(text="ERROR: Invalid input. Positive numbers only, please.", bg='white', fg='red') 


# Amps Function
def amps():
    amps_tab_amps_e.delete(0, END)

    try:
        volts_str = amps_tab_volts_e.get()
        volts = int(volts_str)
        amps_tab_error_Label.configure(text='', bg=orange, fg=orange)
    except ValueError:
        amps_tab_error_Label.configure(text="ERROR: Invalid input. Positive numbers only, please.", bg='white', fg='red')
        return

    try:
        watts_str = amps_tab_watts_e.get()
        watts = int(watts_str)
        amps_tab_error_Label.configure(text='', bg=orange, fg=orange)
    except ValueError:
        amps_tab_error_Label.configure(text="ERROR: Invalid input. Positive numbers only, please.", bg='white', fg='red')
        return
    
    if watts > 0 and volts > 0:
        amps_tab_amps_e.delete(0, END)
        amps_tab_amps_e.insert(0,watts/volts)
    else:
        amps_tab_error_Label.configure(text="ERROR: Invalid input. Positive numbers only, please.", bg='white', fg='red') 



# Volts Function
def volts():
    volts_tab_volts_e.delete(0, END)

    try:
        amps_str = volts_tab_amps_e.get()
        amps = int(amps_str)
        volts_tab_error_Label.configure(text='', bg=orange, fg=orange)
    except ValueError:
        volts_tab_error_Label.configure(text="ERROR: Invalid input. Positive numbers only, please.", bg='white', fg='red')
        return

    try:
        ohms_str = volts_tab_ohms_e.get()
        ohms = int(ohms_str)
        volts_tab_error_Label.configure(text='', bg=orange, fg=orange)
    except ValueError:
        volts_tab_error_Label.configure(text="ERROR: Invalid input. Positive numbers only, please.", bg='white', fg='red')
        return
    
    if amps > 0 and ohms > 0:
        volts_tab_volts_e.delete(0, END)
        volts_tab_volts_e.insert(0,amps*ohms)
    else:
        volts_tab_error_Label.configure(text="ERROR: Invalid input. Positive numbers only, please.", bg='white', fg='red') 


# Create Widets for Welcome Tab
button_quit = Button(welcome_tab, text="Exit Program",bg=blue, command=root.quit)
welcome_label = Label(welcome_tab,bg=orange, text="Hello all! Thanks for using my electrician's calculator!")
welcome_label2 = Label(welcome_tab,bg=orange, text="Please select one of the tabs above to get started.")
ohms_law_label = Label(welcome_tab, image=ohms_law, text="Ohms law chart")
apollo_label = Label(welcome_tab, image=apollo, text="Image of my cat, Apollo")


# Display Welcome Tab widgets on grid
welcome_label.grid(row=0,column=0)
welcome_label2.grid(row=1,column=0)
ohms_law_label.grid(row=2,column=0)
apollo_label.grid(row=2,column=1)
button_quit.grid(row=3,column=0)


# Create Widets for watts tab
watts_tab_calculate = Button(watts_tab, text="Calculate", bg=blue, command=watts)
watts_main_label = Label(watts_tab, text="Please enter voltage and amperage to find wattage.", bg=orange)
watts_tab_volts_label = Label(watts_tab, text ="Voltage: ", bg=orange)
watts_tab_amps_label = Label(watts_tab, text ="Amperage: ", bg=orange)
watts_tab_watts_label = Label(watts_tab, text ="Wattage: ", bg=orange)
watts_tab_error_Label = Label(watts_tab, text=" ", bg=orange, fg=orange)
watts_tab_button_quit = Button(watts_tab, text="Exit Program",bg=blue, command=root.quit)

# Create Watts Tab Entry fields
watts_tab_amps_e = Entry(watts_tab, width=20)
watts_tab_volts_e = Entry(watts_tab, width=20)
watts_tab_watts_e = Entry(watts_tab, width=20)

# Display Watts Tab widgets on grid
watts_main_label.grid(row=0, column=0, columnspan=3)
watts_tab_amps_label.grid(row=1, column=0)
watts_tab_amps_e.grid(row=1, column=1)
watts_tab_volts_label.grid(row=2, column=0)
watts_tab_volts_e.grid(row=2, column=1)
watts_tab_watts_label.grid(row=3, column=0)
watts_tab_watts_e.grid(row=3, column=1)
watts_tab_calculate.grid(row=3, column=3)
watts_tab_error_Label.grid(row=4,column=0,columnspan=3)
watts_tab_button_quit.grid(row=5,column=0)


# Create Amps Widgets
amps_tab_calculate = Button(amps_tab, text="Calculate", bg=blue, command=amps)
amps_main_label = Label(amps_tab, text="Please enter voltage and wattage to find amperage.", bg=orange)
amps_tab_volts_label = Label(amps_tab, text ="Voltage: ", bg=orange)
amps_tab_amps_label = Label(amps_tab, text ="Amperage: ", bg=orange)
amps_tab_watts_label = Label(amps_tab, text ="Wattage: ", bg=orange)
amps_tab_error_Label = Label(amps_tab, text=" ", bg=orange, fg=orange)
amps_tab_button_quit = Button(amps_tab, text="Exit Program",bg=blue, command=root.quit)

# Create Amps Tab Entry fields
amps_tab_amps_e = Entry(amps_tab, width=20)
amps_tab_volts_e = Entry(amps_tab, width=20)
amps_tab_watts_e = Entry(amps_tab, width=20)

# Display Amps Tab widgets on grid
amps_main_label.grid(row=0, column=0, columnspan=3)
amps_tab_amps_label.grid(row=3, column=0)
amps_tab_amps_e.grid(row=3, column=1)
amps_tab_volts_label.grid(row=2, column=0)
amps_tab_volts_e.grid(row=2, column=1)
amps_tab_watts_label.grid(row=1, column=0)
amps_tab_watts_e.grid(row=1, column=1)
amps_tab_calculate.grid(row=3, column=3)
amps_tab_error_Label.grid(row=4,column=0,columnspan=3)
amps_tab_button_quit.grid(row=5,column=0)


# Create Volts Tab widgets
volts_tab_calculate = Button(volts_tab, text="Calculate", bg=blue, command=volts)
volts_main_label = Label(volts_tab, text="Please enter resistance (Ohms) and amperage to find voltage.", bg=orange)
volts_tab_volts_label = Label(volts_tab, text ="Voltage: ", bg=orange)
volts_tab_amps_label = Label(volts_tab, text ="Amperage: ", bg=orange)
volts_tab_ohms_label = Label(volts_tab, text ="Ohms: ", bg=orange)
volts_tab_error_Label = Label(volts_tab, text=" ", bg=orange, fg=orange)
volts_tab_button_quit = Button(volts_tab, text="Exit Program",bg=blue, command=root.quit)

# Create Volts Tab Entry fields
volts_tab_amps_e = Entry(volts_tab, width=20)
volts_tab_volts_e = Entry(volts_tab, width=20)
volts_tab_ohms_e = Entry(volts_tab, width=20)

# Display Volts Tab widgets on grid
volts_main_label.grid(row=0, column=0, columnspan=3)
volts_tab_amps_label.grid(row=2, column=0)
volts_tab_amps_e.grid(row=2, column=1)
volts_tab_volts_label.grid(row=3, column=0)
volts_tab_volts_e.grid(row=3, column=1)
volts_tab_ohms_label.grid(row=1, column=0)
volts_tab_ohms_e.grid(row=1, column=1)
volts_tab_calculate.grid(row=3, column=3)
volts_tab_error_Label.grid(row=4,column=0,columnspan=3)
volts_tab_button_quit.grid(row=5,column=0)


root.mainloop()